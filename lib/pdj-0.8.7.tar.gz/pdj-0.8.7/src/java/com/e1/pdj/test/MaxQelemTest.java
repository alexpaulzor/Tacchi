package com.e1.pdj.test;

import junit.framework.TestCase;

public class MaxQelemTest extends TestCase {

}
