
package com.cycling74.max;

import java.util.Set;

/**
 * MaxContext holder. Does not do anything usefull on pdj, yet.
 */
public class MaxContext {
	public Set getAllObject() {
		return null;
	}
	
	MaxObject getMaxObject(String name) {
		return null;
	}
	
	String getMxjVersion() {
		return MaxSystem.MXJ_VERSION;
	}
}
