package com.cycling74.max;

import java.lang.reflect.Method;

class InletDispatch {
	Method method = null;
	boolean atoms = true;
}