import com.cycling74.max.Atom;
import com.e1.pdj.js.JavaJavaScript;


public class jjs extends JavaJavaScript {
	public jjs(Atom args[]) {
		super(args);
	}
}
